
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#" style="font-weight: 900;">CO2</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse  mr-lg-4" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active2" id="link1">
                <a class="nav-link" href="./index.php">Forside <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item " id="link2">
                <a class="nav-link" href="./Introduktion.php">Introduktion <span class="sr-only">(current)</span></a>
            </li>
            <?php if(isset($_SESSION['username'])){ ?>
                        <li class="nav-item "  id="link3">
                <a class="nav-link" href="./beregning.php">Beregning <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item"  id="link4">
                <a class="nav-link" href="./result.php">Resultat</a>
            </li><?php } else{ }?>
        </ul>
        <div class="form-inlines">
          
      <form method="POST" action="index.php">
        <button class="btn button3" name="login" value="<?php if(isset($_SESSION['username'])){ echo "Logout";}else{
            echo "Login";
        } ?>" type="submit"><?php
        if(isset($_SESSION['username'])){ echo "Logout";}else{
            echo "Login";
        } ?></button>
        </form>
        </div>
 
    </div>
</nav>

<!-- <nav>
        <div class="logo">
            <img src="logo.svg" alt="Logo Image">
        </div>
        <div class="hamburger">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
        </div>
        <ul class="nav-links">
            <li><a href="#">Home</a></li>
            <li><a href="#">Solutions</a></li>
            <li><a href="#">Products</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Contact Us</a></li>
            <li><button class="login-button" href="#">Login</button></li>
            <li><button class="join-button" href="#">Join</button></li>
        </ul>
    </nav> -->