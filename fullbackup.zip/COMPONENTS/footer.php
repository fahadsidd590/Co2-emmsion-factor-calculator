<!-- Footer Content Here -->
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="./assets/js/jquery.js"></script>
<script src="./assets/js/popper.js"></script>

<script src="./assets/js/bootstrap.min.js"></script>
<script src="./assets/js/custom.js"></script>
</body>

</html>