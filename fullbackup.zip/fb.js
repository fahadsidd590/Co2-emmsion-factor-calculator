Array ( [resourceName] => people/c3717878108559445182 [etag] => %EgoBAgsMEC43PT9AGgECIgwyYTdXV1cxaUZjOD0= 
[names] => Array ( [0] => Array ( [metadata] => 
Array ( [primary] => 1 [source] => Array ( [type] => CONTACT [id] => 33988e710ae30cbe ) ) 
[displayName] => Ali shah [familyName] => shah [givenName] => Ali [displayNameLastFirst] => 
shah, Ali [unstructuredName] => Ali shah ) ) [phoneNumbers] => Array ( [0] => Array ( [metadata] => 
Array ( [primary] => 1 [source] => Array ( [type] => CONTACT [id] => 33988e710ae30cbe ) )
 [value] => 0349 1268829 [canonicalForm] => +923491268829 ) ) [organizations] => Array ( [0] => 
 Array ( [metadata] => Array ( [primary] => 1 [source] => Array 
 ( [type] => CONTACT [id] => 33988e710ae30cbe ) ) [name] => webnike [title] => python developer ) ) ) 



// family name
//contact id
//given name
// oraginzation names
// phone number
//phone type '
//notes
//address type
//address street

curl \
  'https://people.googleapis.com/v1/people/me/connections?personFields=phoneNumbers%2Cnames%2Corganizations%2Caddresses&sources=READ_SOURCE_TYPE_CONTACT&key=[YOUR_API_KEY]' \
  --header 'Authorization: Bearer [YOUR_ACCESS_TOKEN]' \
  --header 'Accept: application/json' \
  --compressed


  access_token=

  curl \
  'https://people.googleapis.com/v1/people/me/connections?personFields=phoneNumbers%2Cnames&sources=READ_SOURCE_TYPE_CONTACT&key=[YOUR_API_KEY]' \
  --header 'Authorization: Bearer [YOUR_ACCESS_TOKEN]' \
  --header 'Accept: application/json' \
  --compressed



  Array ( [resourceName] => people/c9069357617239759997 [etag] => %EgsBAgULDBAuNz0/QBoBAiIMRTQyNjJScU9HcWM9 [names] => Array 
  ( [0] => Array ( [metadata] => Array ( [primary] => 1 [source] => Array ( [type] => CONTACT [id] => 7ddcd4b38c8f1c7d ) )
   [displayName] => Unicredit Banca Chiusi [givenName] => Unicredit Banca Chiusi [displayNameLastFirst] => Unicredit Banca Chiusi
    [unstructuredName] => Unicredit Banca Chiusi ) ) [addresses] => Array ( [0] => Array ( [metadata] => Array ( [primary] => 1 [source] 
           => Array ( [type] => CONTACT [id] => 7ddcd4b38c8f1c7d ) ) [formattedValue] => Piazza Giacomo Matteotti, 7,
       53043 Chiusi Scalo [type] => home [formattedType] => Home [streetAddress] => Piazza Giacomo Matteotti, 7, 53043 Chiusi Scalo ) ) 
       [phoneNumbers] => Array ( [0] => Array ( [metadata] => Array ( [primary] => 1 [source] => Array 
        ( [type] => CONTACT [id] => 7ddcd4b38c8f1c7d ) ) [value] => 0578071011 [canonicalForm] => +390578071011 [type] => work 
        [formattedType] => Work ) ) [biographies] => Array ( [0] => Array ( [metadata] => Array ( [primary] => 1 [source] => Array
           ( [type] => CONTACT [id] => 7ddcd4b38c8f1c7d ) ) [value] => Unicredit Banca Chiusi 0578/ 071011 [contentType] => TEXT_PLAIN ) ) )



           
