
<!doctype html>
<html lang="en">
<?php
session_start();
?>
<?php ?>
  <?php if(isset($_POST['login'])){
    
            if($_POST['login']=="Logout"){
                // echo "hello1";
                session_unset();
                // session_destroy();
                header('./index.php');
            }
            else{
                // echo "hello2";

                header('location: login.php');
            }
            }            
            ?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS Here -->
    <link rel="stylesheet" href="./assets/css/Bootstrap.css">
    <link rel="stylesheet" href="./assets/css/theme.css">
    <link rel="stylesheet" href="./assets/css/custom.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Libs CSS Here -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js'></script>
    <!-- <link rel="stylesheet" type="text/css" href="http://www.shieldui.com/shared/components/latest/css/light/all.min.css"/> -->
    <link rel="stylesheet" href="./assets/libs/Font-Awsome-6/css/all.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />
    <title>ORDER11438 - CO2 Emmision Project</title>
    
</head>
<body>
    <?php require_once('./COMPONENTS/navbar.php') ?>